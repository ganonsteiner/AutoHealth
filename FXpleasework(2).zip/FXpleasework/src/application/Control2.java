package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class Control2 {
     @FXML
	Label userName;
     
    public  void displayName(String username) { 
    	userName.setText("Welcome: " + username);
    }
}
