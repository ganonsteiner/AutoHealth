package application;

public class Presciption {
	String prescriptionName;
	String address;
	
	public Presciption(String inName, String inAdd ) {
		prescriptionName = inName;
		address = inAdd;
	}
}
